const $ = (id) => document.getElementById(id);

const tabs = document.querySelectorAll(".tab");
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    document.querySelectorAll(".panel").forEach(p => p.classList.add("hidden"));
    $(tab.dataset.section).classList.remove("hidden");
  });
});

function apiUrl(path) {
  const base = (window.JJK_API_URL || "").replace(/\/$/, "");
  if (!base || base.includes("PASTE_BACKEND_URL")) {
    throw new Error("Не указан URL backend. Открой config.js и вставь URL своего backend-сервера.");
  }
  return base + path;
}

async function postJSON(path, body) {
  const response = await fetch(apiUrl(path), {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Ошибка сервера");
  return data;
}

$("generateProfile").addEventListener("click", async () => {
  const btn = $("generateProfile");
  const loading = $("profileLoading");
  const result = $("profileResult");
  btn.disabled = true;
  loading.classList.remove("hidden");
  result.classList.add("hidden");

  try {
    const data = await postJSON("/profile", {
      rank: $("rank").value,
      wish: $("characterWish").value.trim()
    });
    $("profileText").textContent = data.text;
    result.classList.remove("hidden");
  } catch (error) {
    alert(error.message);
  } finally {
    btn.disabled = false;
    loading.classList.add("hidden");
  }
});

$("copyProfile").addEventListener("click", async () => {
  await navigator.clipboard.writeText($("profileText").textContent);
  $("copyProfile").textContent = "Скопировано";
  setTimeout(() => $("copyProfile").textContent = "Копировать", 1200);
});

let referenceDataUrl = "";

$("referenceImage").addEventListener("change", () => {
  const file = $("referenceImage").files[0];
  if (!file) return;
  if (file.size > 8 * 1024 * 1024) {
    alert("Изображение слишком большое. Максимум 8 МБ.");
    $("referenceImage").value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    referenceDataUrl = reader.result;
    $("imagePreview").src = referenceDataUrl;
    $("imagePreview").classList.remove("hidden");
  };
  reader.readAsDataURL(file);
});

$("generateAppearance").addEventListener("click", async () => {
  const btn = $("generateAppearance");
  const loading = $("appearanceLoading");
  const result = $("imageResult");
  btn.disabled = true;
  loading.classList.remove("hidden");
  result.classList.add("hidden");

  try {
    const data = await postJSON("/appearance", {
      referenceImage: referenceDataUrl || null,
      wish: $("appearanceWish").value.trim()
    });
    $("generatedImage").src = "data:image/png;base64," + data.image;
    $("saveImage").href = "data:image/png;base64," + data.image;
    result.classList.remove("hidden");
  } catch (error) {
    alert(error.message);
  } finally {
    btn.disabled = false;
    loading.classList.add("hidden");
  }
});
