const PROFILE_INSTRUCTIONS = `
Ты — AI-генератор оригинальных персонажей для ролевой игры во вселенной Jujutsu Kaisen («Магическая битва»).

Создавай НОВЫХ персонажей, а не копируй существующих.

СТРОГИЕ ПРАВИЛА:
1. Используй логику мира Jujutsu Kaisen: проклятая энергия, врождённые техники, расширения техники, обратная проклятая техника, максимальная техника, раскрытие территории и общеизвестные техники.
2. Не добавляй Binding Vow / «клятвы» ни под каким видом.
3. Не выдавай персонажу автоматически все сильнейшие способности. Максимальная техника, обратная техника и раскрытие территории появляются только если это логично для ранга, опыта и концепции.
4. Врождённая техника должна быть оригинальной и иметь понятный принцип работы, применения, ограничения и контрмеры.
5. Не копируй Бесконечность, Шесть глаз, Десять теней, Копирование, техники Сукуны и другие канонические способности.
6. Ранг должен соответствовать силе персонажа. Особый ранг используй только для действительно исключительных персонажей.
7. Если пожелания пользователя противоречат логике мира, адаптируй их так, чтобы персонаж оставался играбельным.
8. Пиши на русском.
9. Верни ТОЛЬКО анкету без вступления и комментариев.

ФОРМАТ:
~ШАБЛОН АНКЕТЫ~

{ИМЯ}:

{РОСТ/ВЕС}:

{Врождённая техника}:
(Техника которая у вашего персонажа с рождения)

{Техники}:(обще доступные техники)

{ПРЕД ИСТОРИЯ}:(не обязательно но желательно)

{Возраст}:(возраст вашего персонажа)

{Интересный факт}:(не обязательно)

{РАНГ}:

При необходимости добавь:
{Максимальная техника}:
{Обратная проклятая техника}:
{Раскрытие территории}:
`;

const TEXT_MODEL = "@cf/zai-org/glm-4.7-flash";
const IMG_MODEL = "@cf/stabilityai/stable-diffusion-xl-base-1.0";
const IMG2IMG_MODEL = "@cf/runwayml/stable-diffusion-v1-5-img2img";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders() }
  });
}

function dataUrlToBase64(dataUrl) {
  const match = String(dataUrl).match(/^data:[^;]+;base64,(.+)$/s);
  return match ? match[1] : String(dataUrl);
}

function bytesToBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }

    if (request.method !== "POST") {
      return json({ error: "Use POST" }, 405);
    }

    const url = new URL(request.url);

    try {
      if (!env.AI) {
        throw new Error("Workers AI binding AI не подключён.");
      }

      const body = await request.json();

      if (url.pathname === "/profile") {
        const rankMap = {
          random: "выбери сам логичный ранг",
          "4": "4 ранг",
          "3": "3 ранг",
          "2": "2 ранг",
          "1": "1 ранг",
          special: "особый ранг"
        };

        const userPrompt = `
Желаемый ранг: ${rankMap[body.rank] || "выбери сам"}.
Пожелания пользователя: ${body.wish || "нет конкретных пожеланий"}.

Создай оригинального персонажа. Проверь баланс: принцип техники, применение, расход проклятой энергии, ограничения, контрмеры и соответствие рангу.
`;

        const result = await env.AI.run(TEXT_MODEL, {
          messages: [
            { role: "system", content: PROFILE_INSTRUCTIONS },
            { role: "user", content: userPrompt }
          ],
          max_tokens: 2200,
          temperature: 0.9
        });

        return json({ text: result?.response || "AI не вернул текст." });
      }

      if (url.pathname === "/appearance") {
        const reference = body.referenceImage || null;
        const wish = body.wish || "оригинальная внешность колдуна Jujutsu Kaisen";
        const prompt = `Anime/manga character design inspired by the visual language of dark modern supernatural shonen manga. Original Jujutsu Kaisen-style sorcerer character, full body, clean composition. ${wish}. Detailed face, hairstyle, clothing, accessories, believable combat outfit, expressive but natural pose. Do not copy any existing character.`;

        if (reference) {
          const image_b64 = dataUrlToBase64(reference);
          const stream = await env.AI.run(IMG2IMG_MODEL, {
            prompt,
            negative_prompt: "existing anime character, copied character, logo, watermark, text, blurry, distorted hands, extra fingers",
            image_b64,
            width: 768,
            height: 1024,
            num_steps: 20,
            strength: 0.65,
            guidance: 7.5
          });

          const bytes = new Uint8Array(await new Response(stream).arrayBuffer());
          return json({ image: `data:image/png;base64,${bytesToBase64(bytes)}` });
        }

        const result = await env.AI.run(IMG_MODEL, {
          prompt,
          negative_prompt: "existing anime character, copied character, logo, watermark, text, blurry, distorted hands, extra fingers",
          width: 768,
          height: 1024,
          num_steps: 20,
          guidance: 7.5
        });

        const stream = result?.image ? null : result;
        if (result?.image) {
          return json({ image: `data:image/jpeg;base64,${result.image}` });
        }
        const bytes = new Uint8Array(await new Response(stream).arrayBuffer());
        return json({ image: `data:image/png;base64,${bytesToBase64(bytes)}` });
      }

      return json({ error: "Unknown endpoint" }, 404);
    } catch (error) {
      console.error(error);
      return json({ error: error?.message || "Unknown error" }, 500);
    }
  }
};
