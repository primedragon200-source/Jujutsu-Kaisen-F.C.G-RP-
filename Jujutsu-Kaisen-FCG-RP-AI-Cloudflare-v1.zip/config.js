// URL твоего backend-сервера.
// После публикации Cloudflare Worker/Vercel вставь сюда его URL.
// Например: https://jjk-ai-generator.username.workers.dev
window.JJK_API_URL = "PASTE_BACKEND_URL_HERE";
